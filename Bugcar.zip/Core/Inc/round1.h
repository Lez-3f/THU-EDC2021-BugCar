#ifndef _ROUND_1_H_
#define _ROUND_1_H_

#include"value.h"

extern Object metal[2], beacon[3];

void loop1();

#endif