#ifndef _PLAN_H_
#define _PLAN_H_

#include "value.h"

#define T_trun 5     // 1°
#define T_straight 3 // 1cm

void getBestPlan(Object *points, Object *b_p);

#endif